#!/bin/sh
pid=$(pidof stubby)
kill $pid
