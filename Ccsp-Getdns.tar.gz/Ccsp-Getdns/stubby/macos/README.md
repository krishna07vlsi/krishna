The files in this directory are mainly provided to support implementation of a
separate macOS GUI application to manage Stubby.